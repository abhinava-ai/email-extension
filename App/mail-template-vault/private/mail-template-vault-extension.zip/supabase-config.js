// Public API endpoint only. Never place MySQL credentials here.
globalThis.MAIL_TEMPLATE_VAULT_CONFIG = Object.freeze({
  apiBaseUrl: 'https://peachpuff-barracuda-143070.hostingersite.com',
  accountPortalUrl: 'https://peachpuff-barracuda-143070.hostingersite.com'
});
